/*************************************************
					Quick Sort
				Author : Vineet kumar
				Reference: Cormen - DAA
				Date Written: 18/7/2017

*************************************************/

#include<stdio.h>
#include<stdlib.h>
#define MAX 100

void quicksort(int *, int, int);
int partition(int *, int, int);

int main(){
	int arr[MAX],i,j,temp,n,flag=0;
	
	printf("\nEnter the number of elements: ");
	scanf(" %d",&n);
	for(i=0;i<n;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr[i]);	
	}

	quicksort(arr,0,n-1);
	
	printf("\nThe sorted list is as : \n");

	for(i=0;i<n;i++)
		printf(" %2d",arr[i]);
	printf("\n\n");

	return 0;
}


void quicksort(int *arr, int i, int j){
	int pivot;
		
	if(i < j){
		pivot = partition(arr, i, j);
		quicksort(arr, i, pivot-1);	
		quicksort(arr, pivot+1, j);
	}			
}

int partition(int *arr, int a, int b){
	int temp, newPivot, k = 0, currentPivot = 0 ;
	newPivot = a;	
	currentPivot = arr[a];

	for(k = a +1; k <= b; k++ ){
		if(arr[k] < currentPivot ){
			newPivot++;
			//swap
			temp = arr[k];
			arr[k] = arr[newPivot];
			arr[newPivot] = temp;
		}
	}
	arr[a] = arr[newPivot];
	arr[newPivot] = currentPivot;

	return newPivot;
}
