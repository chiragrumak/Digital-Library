#include<stdio.h>
#include<stdlib.h>
#define size 100

int  array[size],front=-1,rear = -1;

void Enqueue();
void Dequeue();

int main(){
	int ch;
	while(1){
		printf("1)Enqueue\n2)Dequeue\n3)exit\n\nEnter your choice...");
		scanf("%d",&ch);
	
		switch(ch)
		{
			case 1: Enqueue();break;
			case 2: Dequeue();break;
			case 3: exit(0);
			default: printf("\nInvalid Option...\n");
		}
	}
	return 0;
}

void Enqueue(){
	int item;
	
	if(rear==size-1){
		printf("\nQueue overflow!\n");
		return;
	}
	printf("\nEnter the value of the item: ");
	scanf("%d",&item);	
	
	if(front==-1) front =0;
	array[++rear] = item;
}

void Dequeue(){
	if(front==-1 || front == rear  +1){
		printf("\nQueue underflow!\n");
		return;
	}
	printf("\n%d\n",array[front++]);
	
}
