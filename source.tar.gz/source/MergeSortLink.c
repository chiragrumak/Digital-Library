#include<stdio.h>
#include<stdlib.h>
#include <assert.h> 

#define MAX 100


struct node{
	int info;
	struct node *next;
};

typedef struct node NODE;
typedef struct node * NODEPOINTER;

NODEPOINTER createList(NODEPOINTER);
NODEPOINTER mergeSort(NODEPOINTER);
void display(NODEPOINTER);
NODEPOINTER divide(NODEPOINTER);
NODEPOINTER merge(NODEPOINTER,NODEPOINTER);

int main(){
	NODEPOINTER start=NULL;
        start =	createList(start);
	display(start);	
	start = mergeSort(start);
	display(start);	

	return 0;
}

NODEPOINTER mergeSort(NODEPOINTER start){
	NODEPOINTER start_First, start_Second, start_Merged;
	if(start!=NULL && start->next!=NULL){
		start_First = start;
		start_Second = divide(start);
		start_First = mergeSort(start_First);
		start_Second = mergeSort(start_Second);	
		start_Merged = merge(start_First,start_Second);
		return start_Merged;			
	}
	else return start;	
	
}

NODEPOINTER divide(NODEPOINTER start){
	NODEPOINTER move_One_Step, move_Two_Step, start_Second;	
	move_Two_Step = start->next->next;
	move_One_Step = start;
	while(move_Two_Step!=NULL){
		move_One_Step = move_One_Step->next;
		move_Two_Step = move_Two_Step->next;
		if(move_Two_Step!=NULL)
			move_Two_Step = move_Two_Step->next;	
	}
	start_Second = move_One_Step->next;
	move_One_Step->next = NULL;
	return start_Second;
}

NODEPOINTER merge(NODEPOINTER first, NODEPOINTER second){
	NODEPOINTER merged_Start, temp;
	
	if(first->info <= second->info){
		merged_Start = first;
		first = first->next;
	}
	else{
		merged_Start = second;
		second = second->next;
	}	
	temp = merged_Start;
	while(first!=NULL && second!=NULL){
		if(first->info <= second->info){
			temp->next = first;
			temp = temp->next;
			first = first->next;
		}
		else{
			temp->next = second;
			temp = temp->next;
			second = second->next;
		}		
	}	

	if(first!=NULL)
		temp->next = first;
	else
		temp->next = second;
	return merged_Start;
}


NODEPOINTER createList(NODEPOINTER start){
    int n, i=0;
    NODEPOINTER temp = start, newnode;
    printf("\nEnter the number of elments to be added: ");
    scanf(" %d",&n);
    printf("\nEnter the element at 0 : ");
    newnode = malloc(sizeof(NODE)); assert(newnode);
    newnode->next = NULL;
    scanf(" %d",&newnode->info);
    temp = newnode;
    start = temp;
    for(i = 1; i < n; i++){
        printf("\nEnter the element at %d : ",i);
        newnode = (NODEPOINTER) malloc(sizeof(NODE)); assert(newnode);
        newnode->next = NULL;
        scanf(" %d",&newnode->info);
        temp->next = newnode;
        temp = newnode;
    }
    
    return start;
}

void display(NODEPOINTER temp){
    while(temp!=NULL){
        printf(" %2d",temp->info);
        temp = temp->next;
    }
    printf("\n\n");
}
