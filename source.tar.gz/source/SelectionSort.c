#include<stdio.h>

#define MAX 100

int main(){
	int arr[MAX],i,j,temp,n,min=0;

	printf("\nEnter the number of elements: ");
	scanf(" %d",&n);
	for(i=0;i<n;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr[i]);	
	}


	for(i=0;i<n-1;i++){
		min = i;
		for(j=i+1;j<n;j++ ){
			if(arr[min]>arr[j])
			   min=j;   	
		}
			
		if(min!=i){
			temp = arr[i];
			arr[i] = arr[min];
			arr[min] = temp;
		}

	}
	printf("\nThe sorted list is as : \n");

	for(i=0;i<n;i++)
		printf(" %2d",arr[i]);
	printf("\n\n");

}

