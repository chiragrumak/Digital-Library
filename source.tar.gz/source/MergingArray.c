#include<stdio.h>
#define MAX 100

void merge(int *arr1,int *arr2,int *arr3,int n1,int n2);

int main(){
	int arr1[MAX],arr2[MAX],arr3[2*MAX],i,j,n1,n2;
	
	printf("\nEnter the number of elements in Array1: ");
	scanf(" %d",&n1);
	for(i=0;i<n1;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr1[i]);	
	}
	
	printf("\nEnter the number of elements in Array2: ");
	scanf(" %d",&n2);
	for(i=0;i<n2;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr2[i]);	
	}

	printf("\nThe Mergerd sorted array is as : \n");
	
	merge(arr1,arr2,arr3,n1,n2);
	for(i=0;i<n1+n2;i++)
		printf(" %2d",arr3[i]);
	printf("\n\n");

	return 0;
}

void merge(int *arr1, int *arr2, int *arr3, int n1, int n2){

	int i=0,j=0,k=0;
	while(i < n1 && j < n2){
		if(arr1[i]<arr2[j])
		 arr3[k++]=arr1[i++];
		else
		 arr3[k++]=arr2[j++];
	}
	while(i<n1)
		arr3[k++] = arr1[i++];
	while(j<n2)
		arr3[k++] = arr2[j++];

}
