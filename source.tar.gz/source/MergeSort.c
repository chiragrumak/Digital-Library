#include<stdio.h>

#define MAX 100

void mergeSort(int *arr, int, int);
void merge(int *arr, int, int, int);

int main(){
	int arr[MAX],i,j,temp,n,flag=0;
	
	printf("\nEnter the number of elements: ");
	scanf(" %d",&n);
	for(i=0;i<n;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr[i]);	
	}

	mergeSort(arr,0,n);
	
	printf("\nThe sorted list is as : \n");

	for(i=0;i<n+1;i++)
		printf(" %2d",arr[i]);
	printf("\n\n");

	return 0;
}


void mergeSort(int *arr, int s, int e){
	int m = 0;
	if(s < e){
		m = (s + e)/2;
		mergeSort(arr,s,m);
		mergeSort(arr,m+1,e);
		merge(arr,s,m,e);		
	}
}


void merge(int *arr, int s, int m, int e){
	int l[MAX],r[MAX],i,j,k;

	for(i = 0; i < m-s+1; i++) l[i] = arr[s+i]; l[m-s+1] = 32767;
	for(j = 0; j < e-m; j++) r[j] = arr[m+j+1]; r[e-m] = 32767;
	i=j=0;
	for(k = s; k <=e;k++ )
		arr[k] = l[i]<r[j] ? l[i++]:r[j++];

}
