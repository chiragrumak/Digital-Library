include<stdio.h>
#include<stdlib.h>
#define size 100

int  array[size],top=-1;

void Push();
void Pop();

int main(){
	int ch;
	while(1){
		printf("1)Push in the stack\n2)Pop from the stack\n3)exit\n\nEnter your choice...");
		scanf("%d",&ch);
	
		switch(ch)
		{
			case 1: Push();break;
			case 2: Pop();break;
			case 3: exit(0);
			default: printf("\nInvalid Option...\n");
		}
	}
	return 0;
}

void Push(){
	int item;	
	printf("Enter the value: ");
	scanf("%d",&item);
	
	if(top==size)
	{
		printf("\nStack overflow!\n");
		return ;
	}
	else
		array[++top] = item;
}
void Pop(){
	if(top==-1)
	{
		printf("\nStack Underflow!\n");
		return ;
	}
	else
		printf("%d\n\n",array[top--]);
}
