#include<stdio.h>

#define MAX 100

int main(){
	int arr[MAX],i,j,temp,n=0;
	
	printf("\nEnter the number of elements: ");
	scanf(" %d",&n);
	for(i=0;i<n;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr[i]);	
	}

	
	for(i=0;i<n;i++){
		
		temp=arr[i];
		for(j=i-1;j>=0 && temp<arr[j];j--)
			arr[j+1]=arr[j];	
		arr[j+1]=temp;
	}
	printf("\nThe sorted list is as : \n");

	for(i=0;i<n;i++)
		printf(" %2d",arr[i]);
	printf("\n\n");

}

