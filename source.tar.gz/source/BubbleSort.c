#include<stdio.h>

#define MAX 100

int main(){
	int arr[MAX],i,j,temp,n,flag=0;
	
	printf("\nEnter the number of elements: ");
	scanf(" %d",&n);
	for(i=0;i<n;i++){
		printf("\nEnter element %d: ",i+1);
		scanf(" %d",&arr[i]);	
	}

	
	for(i=0;i<n;i++){
		
		flag = 0;
		for(j=0;j<n-i-1;j++ ){
			if(arr[j]>arr[j+1]){
			    temp = arr[j];
			    arr[j] = arr[j+1];
			    arr[j+1] = temp;
			    flag=1;	
			}
		}
		if(flag==0)
			break;
	}
	printf("\nThe sorted list is as : \n");

	for(i=0;i<n;i++)
		printf(" %2d",arr[i]);
	printf("\n\n");

}

